﻿namespace HelloWorld
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void HelloBtn_Clicked(object sender, EventArgs e)
        {
            HelloWorldText.Text = "Hello World!";
        }
    }

}
